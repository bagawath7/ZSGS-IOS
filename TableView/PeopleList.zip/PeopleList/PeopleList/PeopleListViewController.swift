//
//  PeopleListViewController.swift
//  PeopleList
//
//  Created by zs-mac-4 on 23/09/22.
//

import UIKit

class PeopleListViewController: UIViewController {

    
    var peopleTable : UITableView!
    
    let peopleSection = ["S","B","R"]
    let peopleNames : [[String]] = [
        ["Santhosh","Sakthi","Siva"],
        ["Bagawath","Barani","Barathi"],
        ["Raj","Rebecca"]
    ]
    
    //["Santhosh", "Siva", "Bagawath","Mahesh", "Nadimuthu", "Sudakar", "Rebecca", "Uma", "Rajendran"]
    
    let peopleDesc : [String] = ["031923458", "2491204", "38501398","129058", "124124", "124124", "214124", "124124", "09876543"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "People list"
        setupTableView()
        
    }
    

    
    func setupTableView(){
        peopleTable = UITableView(frame: .zero, style: .grouped)
        peopleTable.frame = CGRect(x: 0, y: 84, width: self.view.frame.width, height:  self.view.frame.height - 84)
        self.view.addSubview(peopleTable)
        
        
        peopleTable.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        peopleTable.delegate = self
        peopleTable.dataSource = self
        
        
    }

}


extension PeopleListViewController : UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return peopleSection.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let currentRows = peopleNames[section]
        return currentRows.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        //let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let currentRows = peopleNames[indexPath.section]
        let currentName = currentRows[indexPath.row]

        cell.textLabel?.text = currentName
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return peopleSection[section]
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let currentName = peopleNames[indexPath.row]
//        let currentNo = peopleDesc[indexPath.row]
        
        
       // print("currentName \(currentName) \n currentNo\(currentNo)")
    }
    
}
