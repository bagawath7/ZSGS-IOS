//
//  PeopleListViewController.swift
//  PeopleList
//
//  Created by zs-mac-4 on 23/09/22.
//

import UIKit


class PeopleListViewController: UIViewController {
    
    
    var peopleTable : UITableView!
    
    let peopleSection = ["S","B","R"]
    let peopleNames : [[String]] = [
        ["Santhosh","Sakthi","Siva"],
        ["Bagawath","Barani","Barathi"],
        ["Raj","Rebecca"]
    ]
    
    //["Santhosh", "Siva", "Bagawath","Mahesh", "Nadimuthu", "Sudakar", "Rebecca", "Uma", "Rajendran"]
    
    let peopleDesc : [String] = ["031923458", "2491204", "38501398","129058", "124124", "124124", "214124", "124124", "09876543"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "People list"
        setupTableView()
        
    }
    

    
    func setupTableView(){
        peopleTable = UITableView(frame: .zero, style: .grouped)
        peopleTable.frame = CGRect(x: 0, y: 84, width: self.view.frame.width, height:  self.view.frame.height - 84)
        self.view.addSubview(peopleTable)
        
        
        let nib = UINib(nibName: "PeopleTableViewCell", bundle: nil)
        peopleTable.register(nib, forCellReuseIdentifier: "cell")
        
        //peopleTable.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        
        peopleTable.delegate = self
        peopleTable.dataSource = self
        
        
    }

}


extension PeopleListViewController : UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return peopleSection.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let currentRows = peopleNames[section]
        return currentRows.count
    }


    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PeopleTableViewCell
        let currentRows = peopleNames[indexPath.section]
        let currentName = currentRows[indexPath.row]

        cell.username.text = currentName
        cell.userrole.text = "Developer"
        
        
        let image_name = "user\(indexPath.row).jpeg"
        var uimage = UIImage(named: image_name)
        if uimage == nil {
            uimage = UIImage(named: "user1.jpeg")
        }
        cell.userimage.image = uimage

        return cell
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return peopleSection[section]
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

    
}
